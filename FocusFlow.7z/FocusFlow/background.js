// Track time spent and block sites
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url) {
    chrome.storage.local.get(["blockedSites"], (result) => {
      const blockedSites = result.blockedSites || [];
      const url = new URL(tab.url);
      if (blockedSites.some(site => url.hostname.includes(site))) {
        chrome.tabs.update(tabId, { url: "chrome://newtab" });
        chrome.notifications.create({
          type: "basic",
          iconUrl: "assets/icon48.png",
          title: "FocusFlow",
          message: "This site is blocked to help you stay focused!"
        });
      }
    });

    // Track time spent
    chrome.storage.local.get(["timeSpent"], (result) => {
      let timeSpent = result.timeSpent || 0;
      timeSpent += 1; // Increment every second (simplified)
      chrome.storage.local.set({ timeSpent });
    });
  }
});

// Background timer management
let backgroundTimerId = null;

function startOrUpdateTimer() {
  chrome.storage.local.get(["timerActive", "timeLeft"], (result) => {
    const timerActive = result.timerActive || false;
    let timeLeft = result.timeLeft || 25 * 60;

    if (timerActive && !backgroundTimerId) {
      backgroundTimerId = setInterval(() => {
        timeLeft--;
        chrome.storage.local.set({ timeLeft });
        if (timeLeft <= 0) {
          clearInterval(backgroundTimerId);
          backgroundTimerId = null;
          chrome.storage.local.set({ timerActive: false, blockedSites: [] });
          chrome.notifications.create({
            type: "basic",
            iconUrl: "assets/icon48.png",
            title: "FocusFlow",
            message: "Time's up! Blocked sites cleared."
          });
          chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
              chrome.tabs.sendMessage(tab.id, { type: "showMotivation", lang: "en" }, () => {
                if (chrome.runtime.lastError) console.log("Motivation not sent.");
              });
            });
          });
        }
      }, 1000);
    } else if (!timerActive && backgroundTimerId) {
      clearInterval(backgroundTimerId);
      backgroundTimerId = null;
    }
  });
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "startTimer") {
    chrome.storage.local.set({ timerActive: true });
    startOrUpdateTimer();
  } else if (message.type === "resetTimer") {
    chrome.storage.local.get(["timeLeft"], (result) => {
      const defaultTime = parseInt(document.getElementById("time-options").value) || 25 * 60;
      chrome.storage.local.set({ timerActive: false, timeLeft: defaultTime });
      startOrUpdateTimer();
    });
  }
});

// Start timer on extension load or change
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (changes.timerActive || changes.timeLeft) {
    startOrUpdateTimer();
  }
});

startOrUpdateTimer(); // Initialize on load