// Language Support
const translations = {
  en: { title: "FocusFlow", start: "Start", stats: "Stats", add: "Add", remove: "Remove", warning: "Warning: Blocking list will be active until timer ends. Continue?" },
  lv: { title: "FocusFlow", start: "Sākt", stats: "Statistika", add: "Pievienot", remove: "Dzēst", warning: "Brīdinājums: Bloķēšanas saraksts būs aktīvs līdz taimerim beidzoties. Turpināt?" },
  lt: { title: "FocusFlow", start: "Pradėti", stats: "Statistika", add: "Pridėti", remove: "Šalinti", warning: "Įspėjimas: Blokuojamų svetainių sąrašas bus aktyvus, kol baigsis laikmatis. Tęsti?" },
  ee: { title: "FocusFlow", start: "Alusta", stats: "Statistika", add: "Lisa", remove: "Eemalda", warning: "Hoiatus: Blokeeritud saitide loend jääb aktiivseks, kuni taimer lõpeb. Jätkata?" }
};

let currentLang = "en";
chrome.storage.local.get(["language"], (result) => {
  if (result.language) currentLang = result.language;
  document.getElementById("language").value = currentLang;
  updateLanguage();
});

document.getElementById("language").addEventListener("change", (e) => {
  currentLang = e.target.value;
  chrome.storage.local.set({ language: currentLang });
  updateLanguage();
});

function updateLanguage() {
  const t = translations[currentLang];
  document.getElementById("title").textContent = t.title;
  document.getElementById("start-btn").textContent = t.start;
  document.getElementById("stats").querySelector("h3").textContent = t.stats;
  document.getElementById("add-block-btn").textContent = t.add;
}

// Timer (sinhronizēts ar fonu)
function updateTimerDisplay() {
  chrome.storage.local.get(["timeLeft"], (result) => {
    const timeLeft = result.timeLeft || 25 * 60;
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    const timeStr = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
    document.getElementById("time-display").textContent = timeStr;

    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { type: "updateTimer", time: timeStr }, () => {
          if (chrome.runtime.lastError) console.log("Message not sent.");
        });
      }
    });
  });
}

// Atjaunina laiku reāllaikā
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (changes.timeLeft) {
    updateTimerDisplay();
  }
});

document.getElementById("time-options").addEventListener("change", (e) => {
  const newTime = parseInt(e.target.value);
  chrome.storage.local.set({ timeLeft: newTime });
  updateTimerDisplay();
});

document.getElementById("start-btn").addEventListener("click", () => {
  if (confirm(translations[currentLang].warning)) {
    chrome.storage.local.get(["blockedSites"], (result) => {
      if (result.blockedSites && result.blockedSites.length > 0) {
        chrome.storage.local.set({ timerActive: true });
        chrome.runtime.sendMessage({ type: "startTimer" });
      }
    });
  }
});

// Site Blocker
let blockedSites = [];
chrome.storage.local.get(["blockedSites", "timerActive"], (result) => {
  blockedSites = result.blockedSites || [];
  updateBlockedSitesList(result.timerActive || false);
});

document.getElementById("add-block-btn").addEventListener("click", () => {
  const predefined = document.getElementById("predefined-sites").value;
  const custom = document.getElementById("block-site").value.trim();
  const site = predefined || custom;
  if (site && !blockedSites.includes(site)) {
    blockedSites.push(site);
    chrome.storage.local.set({ blockedSites }, () => {
      updateBlockedSitesList(false); // Dzēšana nav atļauta pirms start
      document.getElementById("block-site").value = "";
      document.getElementById("predefined-sites").value = "";
    });
  }
});

function updateBlockedSitesList(isTimerActive) {
  const list = document.getElementById("blocked-sites");
  list.innerHTML = "";
  blockedSites.forEach((site, index) => {
    const li = document.createElement("li");
    li.innerHTML = `${site} ${!isTimerActive ? `<button data-index="${index}">${translations[currentLang].remove}</button>` : ""}`;
    if (!isTimerActive) {
      li.querySelector("button").addEventListener("click", () => {
        blockedSites.splice(index, 1);
        chrome.storage.local.set({ blockedSites }, () => updateBlockedSitesList(false));
      });
    }
    list.appendChild(li);
  });
}

// Stats
chrome.storage.local.get(["timeSpent"], (result) => {
  const timeSpent = result.timeSpent || 0;
  document.getElementById("time-spent").textContent = `Time spent today: ${Math.floor(timeSpent / 60)} min`;
});

// BuyMeACoffee
document.getElementById("coffee-btn").addEventListener("click", () => {
  window.open("https://buymeacoffee.com/latvietis", "_blank");
});

// Theme Toggle
let isDark = true;
document.getElementById("theme-toggle").addEventListener("click", () => {
  isDark = !isDark;
  document.body.className = isDark ? "dark" : "light";
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { type: "updateTheme", isDark }, () => {
        if (chrome.runtime.lastError) console.log("Theme message not sent.");
      });
    }
  });
});

updateTimerDisplay();