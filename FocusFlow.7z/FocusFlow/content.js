const focusFlowContainer = document.createElement("div");
focusFlowContainer.id = "focusflow-container";
focusFlowContainer.style.position = "fixed";
focusFlowContainer.style.top = "10px";
focusFlowContainer.style.right = "10px";
focusFlowContainer.style.zIndex = "9999";
focusFlowContainer.style.fontFamily = "Arial, sans-serif";
focusFlowContainer.style.transition = "all 0.3s ease";

const timerDisplay = document.createElement("div");
timerDisplay.id = "focusflow-timer";
timerDisplay.style.background = "#333";
timerDisplay.style.color = "#fff";
timerDisplay.style.padding = "10px";
timerDisplay.style.borderRadius = "5px";
timerDisplay.style.boxShadow = "0 2px 5px rgba(0, 0, 0, 0.2)";
timerDisplay.textContent = "25:00";

const motivationalMessage = document.createElement("div");
motivationalMessage.id = "focusflow-message";
motivationalMessage.style.marginTop = "10px";
motivationalMessage.style.background = "rgba(0, 0, 0, 0.8)";
motivationalMessage.style.color = "#fff";
motivationalMessage.style.padding = "8px";
motivationalMessage.style.borderRadius = "5px";
motivationalMessage.style.display = "none";

focusFlowContainer.appendChild(timerDisplay);
focusFlowContainer.appendChild(motivationalMessage);
document.body.appendChild(focusFlowContainer);

const quotes = {
  en: ["Stay focused, you've got this!", "One step at a time!", "Keep the momentum going!"],
  lv: ["Saglabā fokusu, tev izdosies!", "Pa vienam solim!", "Turpini iesākto!"],
  lt: ["Išlaikyk dėmesį, tu gali!", "Žingsnis po žingsnio!", "Tęsk pradėtą darbā!"],
  ee: ["Püsi fookuses, sul läheb hästi!", "Üks samm korraga!", "Hoia hoogu üleval!"]
};

function updateTheme(isDark) {
  if (isDark) {
    timerDisplay.style.background = "#333";
    timerDisplay.style.color = "#fff";
    motivationalMessage.style.background = "rgba(0, 0, 0, 0.8)";
  } else {
    timerDisplay.style.background = "#f0f0f0";
    timerDisplay.style.color = "#333";
    motivationalMessage.style.background = "rgba(255, 255, 255, 0.8)";
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "updateTimer") {
    timerDisplay.textContent = message.time;
  } else if (message.type === "showMotivation") {
    const lang = message.lang || "en";
    const randomQuote = quotes[lang][Math.floor(Math.random() * quotes[lang].length)];
    motivationalMessage.textContent = randomQuote;
    motivationalMessage.style.display = "block";
    setTimeout(() => {
      motivationalMessage.style.display = "none";
    }, 5000);
  } else if (message.type === "updateTheme") {
    updateTheme(message.isDark);
  }
});

// Sinhronizē laiku ar fonu
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (changes.timeLeft) {
    const timeLeft = changes.timeLeft.newValue;
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;
    timerDisplay.textContent = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;
  }
});